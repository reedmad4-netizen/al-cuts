import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import crypto from "node:crypto";
import { getDb, mapUserRow, type ClipRowWithPaths } from "./db";
import { getSupabaseClient } from "./supabase";
import type { UserProfile } from "./types";

export const SESSION_COOKIE = "clipx_session";

const AVATAR_PALETTE = [
  "#2563EB",
  "#1D4ED8",
  "#0284C7",
  "#0F172A",
  "#4F46E5",
  "#0D9488",
];

function getJwtSecret(): Uint8Array {
  const secret =
    process.env.CLIPX_AUTH_SECRET ||
    "clipx-ai-studio-hmac-session-key-2026-v1";
  return new TextEncoder().encode(secret);
}

export async function createSessionToken(userId: string): Promise<string> {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("14d")
    .sign(getJwtSecret());
}

export async function verifySessionToken(
  token: string
): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, getJwtSecret());
    return typeof payload.sub === "string" ? payload.sub : null;
  } catch {
    return null;
  }
}

export function setSessionCookie(token: string) {
  cookies().set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 14,
  });
}

export function clearSessionCookie() {
  cookies().set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
}

export async function getCurrentUser(): Promise<UserProfile | null> {
  try {
    const token = cookies().get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const userId = await verifySessionToken(token);
    if (!userId) return null;
    const db = getDb();
    const row = db
      .prepare("SELECT * FROM users WHERE id = ?")
      .get(userId) as Record<string, unknown> | undefined;
    return row ? mapUserRow(row) : null;
  } catch {
    return null;
  }
}

export async function registerAccount(params: {
  email: string;
  password: string;
  displayName: string;
  handle?: string;
}): Promise<{ user: UserProfile; authProvider: "supabase" | "local" }> {
  const db = getDb();
  const email = params.email.trim().toLowerCase();
  const displayName = params.displayName.trim();
  const rawHandle = (
    params.handle?.trim() ||
    email.split("@")[0].replace(/[^a-z0-9_]/gi, "")
  ).replace(/^@+/, "");
  const handle = `@${rawHandle || "creator"}`;

  const existing = db
    .prepare("SELECT id FROM users WHERE email = ?")
    .get(email);
  if (existing) {
    throw new Error("An account with this email already exists. Please sign in.");
  }

  let userId = `user-${crypto.randomUUID().slice(0, 12)}`;
  let authProvider: "supabase" | "local" = "local";

  // If Supabase Auth is configured, register in Supabase Auth first
  const supabase = getSupabaseClient();
  if (supabase) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password: params.password,
      options: { data: { display_name: displayName, handle } },
    });
    if (!error && data.user?.id) {
      userId = data.user.id;
      authProvider = "supabase";
    }
  }

  const passwordHash = await bcrypt.hash(params.password, 10);
  const avatarColor =
    AVATAR_PALETTE[Math.floor(Math.random() * AVATAR_PALETTE.length)];
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO users (id, email, password_hash, display_name, handle, bio, avatar_color, is_demo_account, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`
  ).run(
    userId,
    email,
    passwordHash,
    displayName,
    handle,
    "Gaming creator clipping highlights with CLIPX AI.",
    avatarColor,
    now
  );

  db.prepare(
    `INSERT INTO user_settings (user_id, updated_at) VALUES (?, ?)`
  ).run(userId, now);

  const row = db
    .prepare("SELECT * FROM users WHERE id = ?")
    .get(userId) as Record<string, unknown>;
  return { user: mapUserRow(row), authProvider };
}

export async function loginAccount(params: {
  email: string;
  password: string;
}): Promise<{ user: UserProfile; authProvider: "supabase" | "local" }> {
  const db = getDb();
  const email = params.email.trim().toLowerCase();

  // Check Supabase Auth first when configured
  const supabase = getSupabaseClient();
  if (supabase) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password: params.password,
    });
    if (!error && data.user) {
      let row = db
        .prepare("SELECT * FROM users WHERE email = ?")
        .get(email) as Record<string, unknown> | undefined;
      if (!row) {
        const now = new Date().toISOString();
        const hash = await bcrypt.hash(params.password, 10);
        const name =
          String(data.user.user_metadata?.display_name || email.split("@")[0]);
        db.prepare(
          `INSERT INTO users (id, email, password_hash, display_name, handle, bio, avatar_color, is_demo_account, created_at)
           VALUES (?, ?, ?, ?, ?, '', '#2563EB', 0, ?)`
        ).run(data.user.id, email, hash, name, `@${email.split("@")[0]}`, now);
        db.prepare(
          "INSERT OR IGNORE INTO user_settings (user_id, updated_at) VALUES (?, ?)"
        ).run(data.user.id, now);
        row = db
          .prepare("SELECT * FROM users WHERE id = ?")
          .get(data.user.id) as Record<string, unknown>;
      }
      return { user: mapUserRow(row), authProvider: "supabase" };
    }
  }

  const row = db
    .prepare("SELECT * FROM users WHERE email = ?")
    .get(email) as Record<string, unknown> | undefined;
  if (!row) {
    throw new Error("Invalid email or password.");
  }

  const valid = await bcrypt.compare(
    params.password,
    String(row.password_hash)
  );
  if (!valid) {
    throw new Error("Invalid email or password.");
  }

  return { user: mapUserRow(row), authProvider: "local" };
}

/**
 * Verifies whether the current user owns or is authorized to export/edit a clip.
 */
export function canUserExportClip(
  clip: ClipRowWithPaths,
  user: UserProfile | null
): { allowed: boolean; reason: string } {
  if (!clip.ownerAuthorized) {
    return {
      allowed: false,
      reason:
        "Export blocked: stream ownership or clip authorization has not been verified for this source.",
    };
  }
  if (clip.isDemo) {
    return {
      allowed: true,
      reason: "Authorized CLIPX AI demo sample clip.",
    };
  }
  if (clip.userId && (!user || clip.userId !== user.id)) {
    return {
      allowed: false,
      reason:
        "You must be signed in as the clip owner to export or modify this clip.",
    };
  }
  return {
    allowed: true,
    reason: "Verified channel owner / authorized creator export.",
  };
}
