import { NextResponse } from "next/server";
import { createSessionToken, setSessionCookie } from "@/lib/auth";
import { getDb, getEffectiveSettings, mapUserRow } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function POST() {
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM users WHERE id = 'user-demo'")
    .get() as Record<string, unknown> | undefined;

  if (!row) {
    return NextResponse.json(
      { error: "Demo creator account not found." },
      { status: 404 }
    );
  }

  const user = mapUserRow(row);
  const token = await createSessionToken(user.id);
  setSessionCookie(token);

  const { rawTwitchToken, rawYoutubeKey, rawKickToken, ...settings } =
    getEffectiveSettings(user.id);
  void rawTwitchToken;
  void rawYoutubeKey;
  void rawKickToken;

  return NextResponse.json({ user, settings, authProvider: "demo" });
}
